package pl.agh.mdaniol.med_pharm_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
